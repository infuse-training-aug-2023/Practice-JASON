def serial_average(str)
    arr = str.split('-')
    avg = (arr[1].to_f + arr[2].to_f) / 2
    return "#{arr[0]}-#{avg.round(2)}"
end

input = "123-45.67-89.01"
result = serial_average(input)
puts result