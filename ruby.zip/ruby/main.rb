require 'selenium-webdriver'

Selenium::WebDriver::Chrome::Service.driver_path = "C:/Users/JasonGonsalves/Documents/Automation/chromedriver-win64/chromedriver.exe"

driver = Selenium::WebDriver.for :chrome

driver.get("https://www.w3.org/WAI/UA/2002/06/thead-test")

thead = driver.find_element(:tag_name, "thead")

th = thead.find_elements(:tag_name, "th")

th.each do |th|
    print th.text + "\t"
end