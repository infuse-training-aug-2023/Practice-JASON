def skip_sports(arr, int)
    str_arr = []
    arr.each_with_index do |sport, index|
        if index > int-1
            str_arr.push("#{index}:#{sport}")
        end
    end
    return str_arr
end

sports_arr = ["tennis", "football", "rugby", "hockey", "golf"]
skip_int = 2

puts skip_sports(sports_arr, skip_int)